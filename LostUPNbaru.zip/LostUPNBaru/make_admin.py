import mysql.connector
import os
from dotenv import load_dotenv

load_dotenv()

def make_admin(identifier):
    try:
        conn = mysql.connector.connect(
            host=os.environ.get("DB_HOST"),
            user=os.environ.get("DB_USER"),
            password=os.environ.get("DB_PASSWORD"),
            database=os.environ.get("DB_NAME"),
        )
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET is_admin = 1 WHERE email = %s OR nim = %s", (identifier, identifier))
        conn.commit()
        
        if cursor.rowcount > 0:
            print(f"✅ Berhasil! User dengan NIM/Email '{identifier}' sekarang adalah Admin.")
        else:
            print(f"❌ Gagal: User dengan NIM/Email '{identifier}' tidak ditemukan di database.")
            
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"Terjadi kesalahan saat koneksi database: {e}")

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        make_admin(sys.argv[1])
    else:
        print("Penggunaan: python make_admin.py <nim_atau_email_user>")
