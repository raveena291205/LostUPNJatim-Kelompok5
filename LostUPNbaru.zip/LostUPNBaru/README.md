# LostUPNJatim 🐊

LostUPNJatim adalah platform pelaporan barang hilang dan ditemukan di lingkungan kampus Universitas Pembangunan Nasional (UPN) "Veteran" Jawa Timur. Platform ini dirancang untuk memudahkan mahasiswa dan sivitas akademika dalam mencari barang yang hilang atau melaporkan barang temuan agar cepat kembali ke pemilik aslinya.

## ✨ Fitur Utama

- **Sistem Autentikasi Pengguna**: Login dan Registrasi menggunakan NIM atau Email kampus.
- **Pelaporan Barang Hilang**: Fitur untuk melaporkan barang yang hilang beserta deskripsi detail, lokasi, dan foto.
- **Pelaporan Barang Temuan**: Fitur bagi penemu barang untuk mengunggah informasi barang yang ditemukan agar pemilik dapat menghubunginya.
- **Pencarian dan Filter Cepat**: Mencari barang berdasarkan nama, lokasi kejadian, atau kategori (Dompet, Elektronik, Kunci, dll).
- **Dashboard Admin**: Halaman khusus untuk mengelola, melacak statistik laporan harian/bulanan, dan menghapus laporan yang tidak valid.
- **Notifikasi Kontak via WhatsApp**: Integrasi tombol direct-chat WhatsApp agar pemilik barang bisa langsung menghubungi penemu/pelapor.
- **Desain Modern & Responsif**: UI/UX yang modern (Glassmorphism), dilengkapi dengan transisi animasi halus dan splash konfirmasi custom.

## 🛠️ Tech Stack

Platform ini dibangun menggunakan teknologi modern yang ringan namun kuat:

### **Backend**
- **Bahasa Pemrograman**: Python 3
- **Framework Web**: [Flask](https://flask.palletsprojects.com/) (v3.0.3)
- **Database**: MySQL (diakses menggunakan `mysql-connector-python`)
- **Keamanan**: Hash password dengan Werkzeug Security
- **WSGI Server**: Gunicorn (untuk production)

### **Frontend**
- **Markup & Styling**: HTML5, Vanilla CSS3 (dengan efek Backdrop Blur/Glassmorphism)
- **Templating Engine**: Jinja2
- **Interaktivitas**: Vanilla JavaScript (untuk custom modals, animasi konfirmasi hapus, dsb.)
- **Tipografi**: Plus Jakarta Sans (Google Fonts)

### **Layanan & Deployment**
- **Hosting / Deployment Target**: Google Cloud Platform (GCP) App Engine (dikonfigurasi via `app.yaml`)
- **Manajemen Konfigurasi**: `python-dotenv` untuk *environment variables*.

## 🚀 Cara Menjalankan Project Secara Lokal

Ikuti langkah-langkah di bawah ini untuk menjalankan LostUPNJatim di komputer lokal Anda:

### 1. Prasyarat
- Python 3.8 atau lebih baru.
- MySQL Server yang berjalan lokal atau remote.

### 2. Clone Repositori
```bash
git clone https://github.com/faydzaki/Lost-Upn-Punya-Kel-Pina.git
cd Lost-Upn-Punya-Kel-Pina
```

### 3. Buat Virtual Environment
Dianjurkan menggunakan Virtual Environment untuk mengisolasi dependensi proyek:
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac/Linux
python3 -m venv venv
source venv/bin/activate
```

### 4. Install Dependensi
```bash
pip install -r requirements.txt
```

### 5. Konfigurasi Database (Environment Variables)
Buat file bernama `.env` di root direktori project, lalu isi konfigurasi database sesuai dengan server MySQL Anda:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=password_database_anda
DB_NAME=lostupn_db
SECRET_KEY=kunci_rahasia_untuk_session_flask
```

### 6. Jalankan Aplikasi
Aplikasi akan secara otomatis membuat tabel database yang diperlukan (jika belum ada) pada saat pertama kali dijalankan.
```bash
python main.py
```
Aplikasi sekarang dapat diakses di browser melalui alamat: `http://127.0.0.1:5000`

---

## 👑 Cara Menambahkan User Admin (via CLI)

Platform ini memiliki Dashboard Admin untuk mengelola seluruh data. Untuk menjadikan sebuah akun biasa menjadi Admin:

1. Pastikan Anda sudah membuat akun terlebih dahulu melalui halaman **Daftar/Register** di aplikasi.
2. Buka terminal di dalam folder proyek.
3. Jalankan script `make_admin.py` dengan parameter NIM atau Email akun yang baru didaftarkan.

**Contoh:**
```bash
python make_admin.py email_anda@example.com
```
Atau
```bash
python make_admin.py 21081010xxx
```

Jika berhasil, saat Anda login menggunakan akun tersebut, tombol navigasi **Dashboard Admin** akan muncul di navbar.

## 📂 Struktur Direktori

- `main.py`: Entry point aplikasi, konfigurasi route Flask, koneksi DB, dan inisialisasi tabel.
- `make_admin.py`: Utility script untuk mempromosikan user menjadi admin.
- `requirements.txt`: Daftar semua library Python yang dibutuhkan.
- `.env`: (Harus dibuat) Menyimpan rahasia konfigurasi database dan app secret.
- `app.yaml` & `.gcloudignore`: Konfigurasi untuk deployment ke Google App Engine.
- `templates/`: Berisi seluruh file tampilan frontend (HTML+Jinja2).
- `static/`: Berisi aset statis seperti logo, gambar favicon, maskot, dan folder `uploads/` untuk menyimpan foto laporan barang.

---
*Dibuat untuk mempermudah pencarian barang di lingkungan UPN Veteran Jawa Timur.*🐊