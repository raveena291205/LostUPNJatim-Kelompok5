from flask import Flask, request, render_template, redirect, url_for, session, flash, abort
import mysql.connector
from mysql.connector import Error
import os
import random
import string
from datetime import datetime, timedelta
from dotenv import load_dotenv
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

load_dotenv()

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "fallback-secret-key")

# Konfigurasi upload foto
UPLOAD_FOLDER = os.path.join('static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # Maksimal 5MB

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

LOKASI = [
    "Gedung Rektorat",
    "Gedung A (FISIP)",
    "Gedung B (FEB)",
    "Gedung C (FTK)",
    "Gedung D (FPertanian)",
    "Perpustakaan Pusat",
    "Kantin Pusat",
    "Masjid Kampus",
    "Lapangan Olahraga",
    "Parkiran Motor",
    "Parkiran Mobil",
    "Aula Kampus",
    "Laboratorium Komputer",
    "Koperasi Mahasiswa",
    "Area Depan Kampus",
]

KATEGORI = [
    "Dompet / Kartu",
    "Handphone",
    "Kunci",
    "Tas / Ransel",
    "Laptop",
    "Alat Tulis",
    "Pakaian / Jaket",
    "Perhiasan / Aksesoris",
    "Dokumen / KTP / KTM",
    "Lainnya",
]


def get_db():
    try:
        conn = mysql.connector.connect(
            host=os.environ.get("DB_HOST"),
            user=os.environ.get("DB_USER"),
            password=os.environ.get("DB_PASSWORD"),
            database=os.environ.get("DB_NAME"),
            connection_timeout=10
        )
        return conn
    except Error as e:
        print(f"Error koneksi: {e}")
        return None


def init_db():
    conn = get_db()
    if not conn:
        return
    cursor = conn.cursor()

    # Tabel users
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nim VARCHAR(20) UNIQUE NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            nama VARCHAR(100) NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            is_admin TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Tabel laporan (tambah kolom user_id jika belum ada)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS laporan (
            id INT AUTO_INCREMENT PRIMARY KEY,
            kode VARCHAR(20) UNIQUE NOT NULL,
            jenis ENUM('hilang','ketemu') NOT NULL,
            nama_barang VARCHAR(200) NOT NULL,
            kategori VARCHAR(100) NOT NULL,
            lokasi VARCHAR(200) NOT NULL,
            deskripsi TEXT,
            nama_pelapor VARCHAR(100) NOT NULL,
            kontak_wa VARCHAR(20) NOT NULL,
            foto VARCHAR(255) DEFAULT NULL,
            status ENUM('aktif','selesai') DEFAULT 'aktif',
            user_id INT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        )
    """)

    # Tambah kolom user_id ke tabel laporan yang sudah ada (jika belum ada)
    try:
        cursor.execute("ALTER TABLE laporan ADD COLUMN user_id INT DEFAULT NULL")
        conn.commit()
    except Error:
        pass  # Kolom sudah ada

    conn.commit()
    cursor.close()
    conn.close()
    print("Database siap!")


def generate_kode(jenis):
    prefix = "HLG" if jenis == "hilang" else "KTM"
    suffix = ''.join(random.choices(string.digits, k=6))
    return f"{prefix}-{suffix}"


def format_waktu(dt):
    if not dt:
        return "-"
    wib = dt + timedelta(hours=7)
    return wib.strftime("%d %b %Y, %H:%M")


# ── Decorator auth ──
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login', next=request.url))
        if not session.get('is_admin'):
            abort(403)
        return f(*args, **kwargs)
    return decorated


def simpan_laporan(jenis):
    """Helper function untuk simpan laporan hilang/ketemu"""
    nama_barang  = request.form.get("nama_barang", "").strip()
    kategori     = request.form.get("kategori", "").strip()
    lokasi       = request.form.get("lokasi", "").strip()
    deskripsi    = request.form.get("deskripsi", "").strip()
    nama_pelapor = request.form.get("nama_pelapor", "").strip()
    kontak_wa    = request.form.get("kontak_wa", "").strip()

    if not all([nama_barang, kategori, lokasi, nama_pelapor, kontak_wa]):
        return None, "Semua field wajib diisi!"

    # Handle upload foto
    foto_filename = None
    if 'foto' in request.files:
        foto = request.files['foto']
        if foto and foto.filename and allowed_file(foto.filename):
            ext = foto.filename.rsplit('.', 1)[1].lower()
            foto_filename = f"{generate_kode(jenis)}.{ext}"
            foto.save(os.path.join(app.config['UPLOAD_FOLDER'], foto_filename))

    kode = generate_kode(jenis)
    user_id = session.get('user_id')
    conn = get_db()
    if not conn:
        return None, "Gagal terhubung ke database!"

    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO laporan (kode, jenis, nama_barang, kategori, lokasi, deskripsi, nama_pelapor, kontak_wa, foto, user_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (kode, jenis, nama_barang, kategori, lokasi, deskripsi, nama_pelapor, kontak_wa, foto_filename, user_id))
        conn.commit()
        return kode, None
    except Error as e:
        return None, str(e)
    finally:
        cursor.close()
        conn.close()


# ── Halaman Utama ──
@app.route("/")
def index():
    conn = get_db()
    laporan_hilang = []
    laporan_ketemu = []
    total_selesai = 0
    laporan_terbaru = []
    stats_lokasi = []
    stats_kategori = []
    stats_timeline = []
    total_laporan = 0
    success_rate = 0
    search = request.args.get("search", "").strip()
    filter_lokasi = request.args.get("lokasi", "").strip()
    filter_kategori = request.args.get("kategori", "").strip()

    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            query = "SELECT * FROM laporan WHERE 1=1"
            params = []

            if search:
                query += " AND nama_barang LIKE %s"
                params.append(f"%{search}%")
            if filter_lokasi:
                query += " AND lokasi = %s"
                params.append(filter_lokasi)
            if filter_kategori:
                query += " AND kategori = %s"
                params.append(filter_kategori)

            cursor.execute(query + " AND jenis='hilang' ORDER BY created_at DESC LIMIT 20", params)
            laporan_hilang = cursor.fetchall()

            cursor.execute(query + " AND jenis='ketemu' ORDER BY created_at DESC LIMIT 20", params)
            laporan_ketemu = cursor.fetchall()

            cursor.execute("SELECT COUNT(*) as total FROM laporan WHERE status='selesai'")
            total_selesai = cursor.fetchone()['total']

            # Ambil 3 laporan terbaru untuk hero visual
            cursor.execute("SELECT * FROM laporan ORDER BY created_at DESC LIMIT 3")
            laporan_terbaru = cursor.fetchall()

            # ── Statistik ──
            # Per lokasi (top 5)
            cursor.execute("""
                SELECT lokasi, COUNT(*) as jumlah FROM laporan
                WHERE jenis='hilang'
                GROUP BY lokasi ORDER BY jumlah DESC LIMIT 5
            """)
            stats_lokasi = cursor.fetchall()

            # Per kategori (top 5)
            cursor.execute("""
                SELECT kategori, COUNT(*) as jumlah FROM laporan
                GROUP BY kategori ORDER BY jumlah DESC LIMIT 5
            """)
            stats_kategori = cursor.fetchall()

            # Timeline 7 hari terakhir
            cursor.execute("""
                SELECT DATE(created_at) as tanggal, COUNT(*) as jumlah
                FROM laporan
                WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                GROUP BY DATE(created_at) ORDER BY tanggal ASC
            """)
            stats_timeline = cursor.fetchall()

            # Total dan success rate
            cursor.execute("SELECT COUNT(*) as total FROM laporan")
            total_laporan = cursor.fetchone()['total']
            success_rate = round((total_selesai / total_laporan * 100), 1) if total_laporan > 0 else 0

        except Error as e:
            print(f"Error: {e}")
            total_selesai = 0
            laporan_terbaru = []
        finally:
            cursor.close()
            conn.close()

    return render_template("index.html",
        laporan_hilang=laporan_hilang,
        laporan_ketemu=laporan_ketemu,
        lokasi_list=LOKASI,
        kategori_list=KATEGORI,
        search=search,
        filter_lokasi=filter_lokasi,
        filter_kategori=filter_kategori,
        format_waktu=format_waktu,
        total_selesai=total_selesai,
        laporan_terbaru=laporan_terbaru,
        stats_lokasi=stats_lokasi,
        stats_kategori=stats_kategori,
        stats_timeline=stats_timeline,
        total_laporan=total_laporan,
        success_rate=success_rate
    )


# ── Login ──
@app.route("/login", methods=["GET", "POST"])
def login():
    if 'user_id' in session:
        return redirect(url_for('index'))

    error = None
    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip()
        password   = request.form.get("password", "").strip()

        if not identifier or not password:
            error = "NIM/Email dan password wajib diisi!"
        else:
            conn = get_db()
            if conn:
                try:
                    cursor = conn.cursor(dictionary=True)
                    cursor.execute(
                        "SELECT * FROM users WHERE nim=%s OR email=%s",
                        (identifier, identifier)
                    )
                    user = cursor.fetchone()
                    if user and check_password_hash(user['password_hash'], password):
                        session['user_id'] = user['id']
                        session['user_nama'] = user['nama']
                        session['user_nim'] = user['nim']
                        session['is_admin'] = bool(user['is_admin'])
                        next_url = request.args.get('next') or url_for('index')
                        return redirect(next_url)
                    else:
                        error = "NIM/Email atau password salah!"
                except Error as e:
                    error = f"Terjadi kesalahan: {e}"
                finally:
                    cursor.close()
                    conn.close()
            else:
                error = "Gagal terhubung ke database!"

    return render_template("login.html", error=error)


# ── Register ──
@app.route("/register", methods=["GET", "POST"])
def register():
    if 'user_id' in session:
        return redirect(url_for('index'))

    error = None
    if request.method == "POST":
        nama     = request.form.get("nama", "").strip()
        nim      = request.form.get("nim", "").strip()
        email    = request.form.get("email", "").strip()
        password = request.form.get("password", "").strip()
        confirm  = request.form.get("confirm_password", "").strip()

        if not all([nama, nim, email, password, confirm]):
            error = "Semua field wajib diisi!"
        elif password != confirm:
            error = "Konfirmasi password tidak cocok!"
        elif len(password) < 6:
            error = "Password minimal 6 karakter!"
        else:
            conn = get_db()
            if conn:
                try:
                    cursor = conn.cursor(dictionary=True)
                    # Cek NIM atau email sudah terdaftar
                    cursor.execute("SELECT id FROM users WHERE nim=%s OR email=%s", (nim, email))
                    existing = cursor.fetchone()
                    if existing:
                        error = "NIM atau Email sudah terdaftar!"
                    else:
                        hashed = generate_password_hash(password)
                        cursor.execute(
                            "INSERT INTO users (nim, email, nama, password_hash) VALUES (%s, %s, %s, %s)",
                            (nim, email, nama, hashed)
                        )
                        conn.commit()
                        return redirect(url_for('login') + '?registered=1')
                except Error as e:
                    error = f"Terjadi kesalahan: {e}"
                finally:
                    cursor.close()
                    conn.close()
            else:
                error = "Gagal terhubung ke database!"

    return render_template("register.html", error=error)


# ── Logout ──
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for('index'))


# ── Lapor Hilang ──
@app.route("/lapor/hilang", methods=["GET", "POST"])
@login_required
def lapor_hilang():
    message = None
    if request.method == "POST":
        kode, error = simpan_laporan("hilang")
        if error:
            message = {"type": "error", "text": error}
        else:
            return redirect(url_for("detail", kode=kode) + "?new=1")
    return render_template("lapor_hilang.html",
        lokasi_list=LOKASI, kategori_list=KATEGORI, message=message)


# ── Lapor Ketemu ──
@app.route("/lapor/ketemu", methods=["GET", "POST"])
@login_required
def lapor_ketemu():
    message = None
    if request.method == "POST":
        kode, error = simpan_laporan("ketemu")
        if error:
            message = {"type": "error", "text": error}
        else:
            return redirect(url_for("detail", kode=kode) + "?new=1")
    return render_template("lapor_ketemu.html",
        lokasi_list=LOKASI, kategori_list=KATEGORI, message=message)


# ── Hapus Laporan ──
@app.route("/laporan/<kode>/hapus", methods=["POST"])
def hapus(kode):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db()
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT foto, user_id FROM laporan WHERE kode=%s", (kode,))
            row = cursor.fetchone()

            if not row:
                next_url = request.form.get('next') or url_for('index')
                return redirect(next_url)

            # Cek kepemilikan: pemilik atau admin
            is_owner = row['user_id'] == session['user_id']
            is_admin = session.get('is_admin', False)
            # Laporan lama (user_id=None) hanya bisa dihapus admin
            if row['user_id'] is None:
                if not is_admin:
                    abort(403)
            elif not is_owner and not is_admin:
                abort(403)

            if row and row['foto']:
                foto_path = os.path.join(app.config['UPLOAD_FOLDER'], row['foto'])
                if os.path.exists(foto_path):
                    os.remove(foto_path)
            cursor.execute("DELETE FROM laporan WHERE kode=%s", (kode,))
            conn.commit()
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()
            conn.close()
    next_url = request.form.get('next') or url_for('index')
    return redirect(next_url)


# ── Lacak Laporan ──
@app.route("/lacak")
def lacak():
    kode = request.args.get("kode", "").strip().upper()
    if not kode:
        return redirect(url_for("index"))
    return redirect(url_for("detail", kode=kode))


# ── Detail ──
@app.route("/laporan/<kode>")
def detail(kode):
    conn = get_db()
    laporan = None
    is_owner = False
    is_admin_user = session.get('is_admin', False)

    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM laporan WHERE kode = %s", (kode,))
            laporan = cursor.fetchone()
            if laporan and 'user_id' in session:
                is_owner = (laporan['user_id'] == session['user_id'])
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()
            conn.close()

    can_manage = is_owner or is_admin_user

    return render_template("detail.html",
        laporan=laporan,
        kode=kode,
        format_waktu=format_waktu,
        can_manage=can_manage,
        is_logged_in='user_id' in session
    )


# ── Update Status ──
@app.route("/laporan/<kode>/selesai", methods=["POST"])
def selesai(kode):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db()
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT user_id FROM laporan WHERE kode=%s", (kode,))
            row = cursor.fetchone()

            if row:
                is_owner = row['user_id'] == session['user_id']
                is_admin = session.get('is_admin', False)
                if row['user_id'] is None:
                    if not is_admin:
                        abort(403)
                elif not is_owner and not is_admin:
                    abort(403)

            cursor.execute("UPDATE laporan SET status='selesai' WHERE kode=%s", (kode,))
            conn.commit()
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()
            conn.close()
    return redirect(url_for("detail", kode=kode))


# ── Admin Dashboard ──
@app.route("/admin")
@admin_required
def admin():
    conn = get_db()
    stats = {
        'total': 0, 'hilang': 0, 'ketemu': 0, 'selesai': 0, 'aktif': 0,
        'total_users': 0
    }
    laporan_per_kategori = []
    laporan_per_lokasi = []
    barang_sering_hilang = []
    timeline_30hari = []
    laporan_terbaru = []

    if conn:
        try:
            cursor = conn.cursor(dictionary=True)

            # Total keseluruhan
            cursor.execute("SELECT COUNT(*) as total FROM laporan")
            stats['total'] = cursor.fetchone()['total']

            cursor.execute("SELECT COUNT(*) as total FROM laporan WHERE jenis='hilang'")
            stats['hilang'] = cursor.fetchone()['total']

            cursor.execute("SELECT COUNT(*) as total FROM laporan WHERE jenis='ketemu'")
            stats['ketemu'] = cursor.fetchone()['total']

            cursor.execute("SELECT COUNT(*) as total FROM laporan WHERE status='selesai'")
            stats['selesai'] = cursor.fetchone()['total']

            cursor.execute("SELECT COUNT(*) as total FROM laporan WHERE status='aktif'")
            stats['aktif'] = cursor.fetchone()['total']

            cursor.execute("SELECT COUNT(*) as total FROM users")
            stats['total_users'] = cursor.fetchone()['total']

            # Laporan per kategori
            cursor.execute("""
                SELECT kategori,
                    COUNT(*) as total,
                    SUM(jenis='hilang') as hilang,
                    SUM(jenis='ketemu') as ketemu
                FROM laporan
                GROUP BY kategori ORDER BY total DESC
            """)
            laporan_per_kategori = cursor.fetchall()

            # Laporan per lokasi
            cursor.execute("""
                SELECT lokasi, COUNT(*) as total,
                    SUM(jenis='hilang') as hilang,
                    SUM(jenis='ketemu') as ketemu
                FROM laporan
                GROUP BY lokasi ORDER BY total DESC LIMIT 10
            """)
            laporan_per_lokasi = cursor.fetchall()

            # Barang yang paling sering hilang (top 10 berdasarkan nama_barang)
            cursor.execute("""
                SELECT nama_barang, kategori, COUNT(*) as total
                FROM laporan WHERE jenis='hilang'
                GROUP BY nama_barang, kategori
                ORDER BY total DESC LIMIT 10
            """)
            barang_sering_hilang = cursor.fetchall()

            # Timeline 30 hari terakhir
            cursor.execute("""
                SELECT DATE(created_at) as tanggal,
                    COUNT(*) as total,
                    SUM(jenis='hilang') as hilang,
                    SUM(jenis='ketemu') as ketemu
                FROM laporan
                WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                GROUP BY DATE(created_at) ORDER BY tanggal ASC
            """)
            timeline_30hari = cursor.fetchall()

            # 20 laporan terbaru
            cursor.execute("""
                SELECT l.*, u.nama as nama_user, u.nim as nim_user
                FROM laporan l
                LEFT JOIN users u ON l.user_id = u.id
                ORDER BY l.created_at DESC LIMIT 20
            """)
            laporan_terbaru = cursor.fetchall()

        except Error as e:
            print(f"Error admin: {e}")
        finally:
            cursor.close()
            conn.close()

    success_rate = round((stats['selesai'] / stats['total'] * 100), 1) if stats['total'] > 0 else 0

    return render_template("admin.html",
        stats=stats,
        success_rate=success_rate,
        laporan_per_kategori=laporan_per_kategori,
        laporan_per_lokasi=laporan_per_lokasi,
        barang_sering_hilang=barang_sering_hilang,
        timeline_30hari=timeline_30hari,
        laporan_terbaru=laporan_terbaru,
        format_waktu=format_waktu
    )


if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)