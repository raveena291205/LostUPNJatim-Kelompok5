from flask import Flask, request, render_template, redirect, url_for
import mysql.connector
from mysql.connector import Error
import os
import random
import string
from datetime import datetime, timedelta
from dotenv import load_dotenv
from werkzeug.utils import secure_filename

load_dotenv()

app = Flask(__name__)

# Konfigurasi upload foto
UPLOAD_FOLDER = os.path.join('static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # Maksimal 5MB

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

LOKASI = [
    "Gedung Rektorat",
    "Gedung A (FISIP)",
    "Gedung B (FEB)",
    "Gedung C (FTK)",
    "Gedung D (FPertanian)",
    "Perpustakaan Pusat",
    "Kantin Pusat",
    "Masjid Kampus",
    "Lapangan Olahraga",
    "Parkiran Motor",
    "Parkiran Mobil",
    "Aula Kampus",
    "Laboratorium Komputer",
    "Koperasi Mahasiswa",
    "Area Depan Kampus",
]

KATEGORI = [
    "Dompet / Kartu",
    "Handphone",
    "Kunci",
    "Tas / Ransel",
    "Laptop",
    "Alat Tulis",
    "Pakaian / Jaket",
    "Perhiasan / Aksesoris",
    "Dokumen / KTP / KTM",
    "Lainnya",
]


def get_db():
    try:
        conn = mysql.connector.connect(
            host=os.environ.get("DB_HOST"),
            user=os.environ.get("DB_USER"),
            password=os.environ.get("DB_PASSWORD"),
            database=os.environ.get("DB_NAME"),
            connection_timeout=10
        )
        return conn
    except Error as e:
        print(f"Error koneksi: {e}")
        return None


def init_db():
    conn = get_db()
    if not conn:
        return
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS laporan (
            id INT AUTO_INCREMENT PRIMARY KEY,
            kode VARCHAR(20) UNIQUE NOT NULL,
            jenis ENUM('hilang','ketemu') NOT NULL,
            nama_barang VARCHAR(200) NOT NULL,
            kategori VARCHAR(100) NOT NULL,
            lokasi VARCHAR(200) NOT NULL,
            deskripsi TEXT,
            nama_pelapor VARCHAR(100) NOT NULL,
            kontak_wa VARCHAR(20) NOT NULL,
            foto VARCHAR(255) DEFAULT NULL,
            status ENUM('aktif','selesai') DEFAULT 'aktif',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    cursor.close()
    conn.close()
    print("Database siap!")


def generate_kode(jenis):
    prefix = "HLG" if jenis == "hilang" else "KTM"
    suffix = ''.join(random.choices(string.digits, k=6))
    return f"{prefix}-{suffix}"


def format_waktu(dt):
    if not dt:
        return "-"
    wib = dt + timedelta(hours=7)
    return wib.strftime("%d %b %Y, %H:%M")


def simpan_laporan(jenis):
    """Helper function untuk simpan laporan hilang/ketemu"""
    nama_barang  = request.form.get("nama_barang", "").strip()
    kategori     = request.form.get("kategori", "").strip()
    lokasi       = request.form.get("lokasi", "").strip()
    deskripsi    = request.form.get("deskripsi", "").strip()
    nama_pelapor = request.form.get("nama_pelapor", "").strip()
    kontak_wa    = request.form.get("kontak_wa", "").strip()

    if not all([nama_barang, kategori, lokasi, nama_pelapor, kontak_wa]):
        return None, "Semua field wajib diisi!"

    # Handle upload foto
    foto_filename = None
    if 'foto' in request.files:
        foto = request.files['foto']
        if foto and foto.filename and allowed_file(foto.filename):
            ext = foto.filename.rsplit('.', 1)[1].lower()
            foto_filename = f"{generate_kode(jenis)}.{ext}"
            foto.save(os.path.join(app.config['UPLOAD_FOLDER'], foto_filename))

    kode = generate_kode(jenis)
    conn = get_db()
    if not conn:
        return None, "Gagal terhubung ke database!"

    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO laporan (kode, jenis, nama_barang, kategori, lokasi, deskripsi, nama_pelapor, kontak_wa, foto)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (kode, jenis, nama_barang, kategori, lokasi, deskripsi, nama_pelapor, kontak_wa, foto_filename))
        conn.commit()
        return kode, None
    except Error as e:
        return None, str(e)
    finally:
        cursor.close()
        conn.close()


# ── Halaman Utama ──
@app.route("/")
def index():
    conn = get_db()
    laporan_hilang = []
    laporan_ketemu = []
    search = request.args.get("search", "").strip()
    filter_lokasi = request.args.get("lokasi", "").strip()
    filter_kategori = request.args.get("kategori", "").strip()

    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            query = "SELECT * FROM laporan WHERE 1=1"
            params = []

            if search:
                query += " AND nama_barang LIKE %s"
                params.append(f"%{search}%")
            if filter_lokasi:
                query += " AND lokasi = %s"
                params.append(filter_lokasi)
            if filter_kategori:
                query += " AND kategori = %s"
                params.append(filter_kategori)

            cursor.execute(query + " AND jenis='hilang' ORDER BY created_at DESC LIMIT 20", params)
            laporan_hilang = cursor.fetchall()

            cursor.execute(query + " AND jenis='ketemu' ORDER BY created_at DESC LIMIT 20", params)
            laporan_ketemu = cursor.fetchall()

            cursor.execute("SELECT COUNT(*) as total FROM laporan WHERE status='selesai'")
            total_selesai = cursor.fetchone()['total']

            # Ambil 3 laporan terbaru untuk hero visual
            cursor.execute("SELECT * FROM laporan ORDER BY created_at DESC LIMIT 3")
            laporan_terbaru = cursor.fetchall()

        except Error as e:
            print(f"Error: {e}")
            total_selesai = 0
            laporan_terbaru = []
        finally:
            cursor.close()
            conn.close()

    return render_template("index.html",
        laporan_hilang=laporan_hilang,
        laporan_ketemu=laporan_ketemu,
        lokasi_list=LOKASI,
        kategori_list=KATEGORI,
        search=search,
        filter_lokasi=filter_lokasi,
        filter_kategori=filter_kategori,
        format_waktu=format_waktu,
        total_selesai=total_selesai,
        laporan_terbaru=laporan_terbaru
    )


# ── Lapor Hilang ──
@app.route("/lapor/hilang", methods=["GET", "POST"])
def lapor_hilang():
    message = None
    if request.method == "POST":
        kode, error = simpan_laporan("hilang")
        if error:
            message = {"type": "error", "text": error}
        else:
            return redirect(url_for("detail", kode=kode))
    return render_template("lapor_hilang.html",
        lokasi_list=LOKASI, kategori_list=KATEGORI, message=message)


# ── Lapor Ketemu ──
@app.route("/lapor/ketemu", methods=["GET", "POST"])
def lapor_ketemu():
    message = None
    if request.method == "POST":
        kode, error = simpan_laporan("ketemu")
        if error:
            message = {"type": "error", "text": error}
        else:
            return redirect(url_for("detail", kode=kode))
    return render_template("lapor_ketemu.html",
        lokasi_list=LOKASI, kategori_list=KATEGORI, message=message)


# ── Hapus Laporan ──
@app.route("/laporan/<kode>/hapus", methods=["POST"])
def hapus(kode):
    conn = get_db()
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            # Ambil nama foto dulu sebelum hapus
            cursor.execute("SELECT foto FROM laporan WHERE kode=%s", (kode,))
            row = cursor.fetchone()
            if row and row['foto']:
                foto_path = os.path.join(app.config['UPLOAD_FOLDER'], row['foto'])
                if os.path.exists(foto_path):
                    os.remove(foto_path)
            cursor.execute("DELETE FROM laporan WHERE kode=%s", (kode,))
            conn.commit()
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()
            conn.close()
    return redirect(url_for("index"))


# ── Lacak Laporan ──
@app.route("/lacak")
def lacak():
    kode = request.args.get("kode", "").strip().upper()
    if not kode:
        return redirect(url_for("index"))
    return redirect(url_for("detail", kode=kode))


# ── Detail ──
@app.route("/laporan/<kode>")
def detail(kode):
    conn = get_db()
    laporan = None
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM laporan WHERE kode = %s", (kode,))
            laporan = cursor.fetchone()
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()
            conn.close()
    return render_template("detail.html", laporan=laporan, kode=kode, format_waktu=format_waktu)


# ── Update Status ──
@app.route("/laporan/<kode>/selesai", methods=["POST"])
def selesai(kode):
    conn = get_db()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE laporan SET status='selesai' WHERE kode=%s", (kode,))
            conn.commit()
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()
            conn.close()
    return redirect(url_for("detail", kode=kode))


if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)